import './polyfills.server.mjs';
import"./chunk-NDYDZJSS.mjs";var t=[{path:"",loadComponent:()=>import("./chunk-FTNSG4RC.mjs").then(o=>o.GymsHomePageComponent)},{path:":gym",loadComponent:()=>import("./chunk-I66LSZ4M.mjs").then(o=>o.GymsInfoPageComponent)}];export{t as default};
